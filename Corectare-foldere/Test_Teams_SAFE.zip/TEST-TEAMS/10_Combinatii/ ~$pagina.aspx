Fisier de test pentru workflow-ul de corectare Teams.
Cale in arhiva: 10_Combinatii/ ~$pagina.aspx
Continutul este un placeholder - doar NUMELE conteaza in acest test.
