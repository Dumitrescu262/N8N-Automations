Fisier de test pentru workflow-ul de corectare Teams.
Cale in arhiva: 03_Extensii_Blocate/control-utilizator.ascx
Continutul este un placeholder - doar NUMELE conteaza in acest test.
